/* Colors Printing Start */
var pwl_c = {qty} < 12 ? 0.00 : ({qty} <= 23 ? 12.73 : ({qty} <= 35 ? 9.79 : ({qty} <= 72 ? 7.85 : ({qty} <= 144 ? 5.52 : ({qty} <= 288 ? 5.36 : ({qty} <= 576 ? 5.22 : ({qty} <= 1008 ? 5.15 : ({qty} <= 2016 ? 4.95 : 4.83))))))))); 
/* Colors Printing End */

/* Colors Blank Start */
var bb_c = {qty} < 12 ? 0.00 : ({qty} <= 23 ? 12.09 : ({qty} <= 35 ? 9.31 : ({qty} <= 71 ? 7.45 : ({qty} <= 143 ? 5.25 : ({qty} <= 288 ? 5.10 : ({qty} <= 576 ? 4.96 : ({qty} <= 1008 ? 4.90 : ({qty} <= 2016 ? 4.71 : 4.59)))))))); 
/* Colors Blank End */